import UIKit
import Darwin

//:# 문자열 중에서 한글자 랜덤으로 뽑아내는 함수.

//
//func PickString(_ words: String) -> Character {
//    let x = words.randomElement()!
//    return x
//}
//
//print(PickString("가나다라마바사"))
//

//:# 소수 판별 해보기
//소수 구하기 (나머지의 값이 자기 자신과 1만 있는 경우, 2이상)

//var isPrime: Bool = true  //전역 상수 설정
//
//func primeNum(_ num: Int) -> Bool {
//
//    for i in 2..<num {
//
//        if num % i == 0 {
//            isPrime = false
//        }
//    }
//    return isPrime
//}
//
//if primeNum(13) {
//    print("소수입니다")
//} else {
//    print("소수가 아닙니다")
//}

//func primeNumCheck(_ num: Int) {
//
//    for i in 2..<num {
//        if num % i == 0 {
//            print("소수가 아닙니다")
//            return
//        }
//    }
//    print("소수 입니다")
//}
//
//primeNumCheck(3)



// 2 3 5 7 11 13 17

// 4 % 2 == 0, 4 % 3 == 1   나머지가 0이 포함되면 소수가 아니다
// 5 % 2 == 1, 5 % 3 == 2, 5 % 4 == 1
// 7 % 2 == 1, 7 % 3 == 1, 7 % 4 == 3, 7 % 5 == 2, 7 % 6 == 1




//:# 팩토리얼 함수
//var num = 5
//var total = 0
//
//for i in 1..<num {
//    num = num * i
//    print(num)
//}

// 4x3x2x1
// x(x-1)(x-2)(x-3)...*1
// 6*1 6*2 12*3 36*4 144*5


func factoryFunc(_ num: Int) -> Int {
    
    var x = 1
    
    for i in 1...num {
    
        x = x * i
        print(x)
    }
    return x
}
factoryFunc(5)



//:# 재귀함수
//: 자기 자신을 반복해서 호출하는 함수
//:> 반드시 중지를 시켜주는 조건이 들어가야 한다.... 조건이 없을 시 스택 오버 플로우가 일어날수 있음(앱이 꺼짐)
func factoryFuncc(_ num: Int) -> Int {
    
    if num <= 1 {
        return 1
    }

    return num * factoryFuncc(num - 1)  // 자기 자신을 호출
}
factoryFuncc(5)

//꼬리 재귀 함수

func factory
