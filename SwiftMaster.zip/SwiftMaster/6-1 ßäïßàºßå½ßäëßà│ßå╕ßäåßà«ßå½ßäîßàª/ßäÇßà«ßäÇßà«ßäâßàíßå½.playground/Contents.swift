import UIKit

////구구단
//
//for x in 1...9 {
//    for i in 1...9 {
//        print("\(x) X \(i) = \(x * i)")
//    }
//}
//
//
//// 3의 배수를 찾아보기
//
//var x = 1
//
//while x <= 100 {
//    if x % 3 == 0 {
//        print("3의 배수 발견 : \(x)")
//    }
//    x += 1
//}
//
//for x in 1...100 {
//    if x % 3 != 0 {
//        continue
//    }
//    print("3의 배수 발견 : \(x)")
//}


//반복문 활용

var x = "😂"

for i in 1...5 {  // let i = 1
    for k in 1...5 {  //let j = 1, 2, 3, 4, 5
        if k <= i {   //11 12 13 14 15, 21 22 23 24 25
            print("😂", terminator: "")
        }
    }
    print()  // 엔터 의미
}
