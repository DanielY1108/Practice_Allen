import UIKit

/*:
 ## 메모리 누수(Memory Leak)의 사례
 * 강한참조 사이클로 인한 메모리누수의 사례
 ---
 */
class Dog {
    var name = "초코"
    
    var run: (() -> Void)?
   
    func saveClosure() {
        // 클로저를 인스턴스의 변수에 저장
        run = {                          // saveClosure함수 실행시 객체(run)이 클로저를 참조 (클로저 RC +1)
            print("\(self.name)가 뛴다.")  // 여기선 클로저(self.name)이 객체(name)을 참조킨다. (choco: RC +1)
        }
    }
    
    deinit {
        print("\(self.name) 메모리 해제")
    }
}


func doSomething() {
    let choco: Dog? = Dog()    // choco: RC +1
    choco?.saveClosure()       // 강한 참조사이클 일어남 (메모리 누수가 일어남)
}

doSomething()

// 실행 끝나면 choco: RC -1

// Total RC == 클로저 RC: 1, choco RC: 1






//Copyright (c) 2021 we.love.code.allen@gmail.com
//
//Permission is hereby granted, free of charge, to any person obtaining a copy
//of this software and associated documentation files (the "Software"), to deal
//in the Software without restriction, including without limitation the rights
//to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//copies of the Software, and to permit persons to whom the Software is
//furnished to do so, subject to the following conditions:
//
//The above copyright notice and this permission notice shall be included in
//all copies or substantial portions of the Software.
//
//Notwithstanding the foregoing, you may not use, copy, modify, merge, publish,
//distribute, sublicense, create a derivative work, and/or sell copies of the
//Software in any work that is designed, intended, or marketed for pedagogical or
//instructional purposes related to programming, coding, application development,
//or information technology.  Permission for such use, copying, modification,
//merger, publication, distribution, sublicensing, creation of derivative works,
//or sale is expressly withheld.
//
//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//THE SOFTWARE.
