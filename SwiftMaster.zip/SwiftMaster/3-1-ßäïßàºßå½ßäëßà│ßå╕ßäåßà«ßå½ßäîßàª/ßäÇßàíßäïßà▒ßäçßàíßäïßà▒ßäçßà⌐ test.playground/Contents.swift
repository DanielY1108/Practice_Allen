import UIKit

var compuerPick = 0
var myPick = 2  // 0 = 가위, 1 = 바위, 2 = 보

switch compuerPick {
case 0:
    print("컴 = 가위 0")
case 1:
    print("컴 = 바위 1")
case 2:
    print("컴 = 보 2")
default:
    break
}
switch myPick {
case 0:
    print("나 = 가위 0")
case 1:
    print("나 = 바위 1")
case 2:
    print("나 = 보 2")
default:
    break
}

//if문 가위 바위 보
if myPick == compuerPick {
    print("win")
} else if myPick == 0 && compuerPick == 2 {
    print("win")
} else if myPick == 2 && compuerPick == 1 {
    print("win")
} else if myPick == 1 && compuerPick == 0 {
    print("win")
} else {
    print("lose")
}


var randomNum = Int.random(in: 1...10)
var myNum = Int.random(in: 1...10)

if myNum > randomNum {
    print("up")
} else if myNum < randomNum {
    print("down")
} else {
    print("bingo")
}
