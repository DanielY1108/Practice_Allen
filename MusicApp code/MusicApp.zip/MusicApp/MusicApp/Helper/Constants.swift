//
//  Constants.swift
//  MusicApp
//
//  Created by JinSeok Yang on 2022/10/15.
//

import Foundation

struct Constant {
    
    static var url = "https://itunes.apple.com/search?media=music&term"

    
}
