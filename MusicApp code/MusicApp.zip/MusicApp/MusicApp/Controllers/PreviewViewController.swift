

import UIKit
import AVKit
import AVFoundation


class PreviewViewController: UIViewController {
    
    var musicData: Music?
    lazy var url = self.musicData?.previewURL
    
    override func viewDidLoad() {
        super.viewDidLoad()
        playVideo(url: url!)
    }
    
    
    func playVideo(url: String) {
        let videoURL = URL(string: url)
        let player = AVPlayer(url: videoURL!)
        let playerLayer = AVPlayerLayer(player: player)
        playerLayer.frame = self.view.bounds
        playerLayer.videoGravity = .resizeAspect
        self.view.layer.addSublayer(playerLayer)
        player.play()
    }
    
    
}
